package com.hexaware.fastx.enums;

public enum BusType {
    AC_SLEEPER,
    NON_AC_SLEEPER,
    AC_SEATER,
    NON_AC_SEATER,
    VOLVO
}
